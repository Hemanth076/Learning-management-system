package com.example.themebased;

public class Constants3 {
    public static final String STORAGE_PATH_QPAPER = "lnotes/";
    public static final String DATABASE_PATH_QPAPER = "lnotes";
}
